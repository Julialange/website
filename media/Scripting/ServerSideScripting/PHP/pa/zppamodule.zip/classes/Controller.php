<?php
/**
 * Class PAController
 *
 * Controlles the inclusion of the protected area module.
 * 
 * @author  Daniel Friedrich
 * @version 1.0 09.11.2011
 * @copyright (c)2011 zeta Software GmbH
 */

require_once('business/Login.php');

class PAController
{   
	private $request = null;   
	private $action = null;   
	private $template = '';
	private $model = null;
	private $loginController = null;

	/**  
	 * Contructor
	 *  
	 * @param Array $request Array of $_GET & $_POST.  
	 */  
	public function PAController(
		$request)
	{   
		$this->request = $request;   
		$this->template = 'login';
		
		$this->loginController = new PALogin( $this );
		
		$this->action = empty( $request['action'] ) ? null : $request['action'];
		
		if ( strcasecmp( $_SERVER["QUERY_STRING"], "palogout" ) == 0)
		{
			$this->action = "palogout";
		}
						
		// Writes the page password and site URL to the session if not done already.
		$this->loginController->getPagePassword();
		$this->getSiteUrl();
	}   
	
	/**
	* Displays the content / Processes input
	* 
	* @return String Content. 
	*/
	public function Display()
	{   	
		$status = '';
		$action = $this->action;
		$view = new PAView();
		$view->SetTemplate( $this->template ); 
		$view->Assign('action', $action);
		$view->Assign('siteUrl', $this->getSiteUrl());
		$view->Assign('areaName', $this->getArea());
		$view->Assign('areaTitle', $this->getAreaTitle());
		$view->Assign('isLoggedIn', $this->loginController->getIsLoggedIn() );
			
		if( isset( $action ))
		{
			switch ( $action )
			{	
				case 'login':
					$this->loginController->LoginUser( 
						$this->request,
						$view);
					exit();
					break;
					
				case 'palogout':
					$this->loginController->LogoutUser( 
						$this->request,
						$view);
					header("Location: " . $this->getSiteUrl() );
					exit();
					break;
			}
		}
		
		if ( $this->loginController->getIsLoggedIn() )
		{
			
		}
		else
		{
			$this->DisplayLogin(
						$this->request,
						$view);
			echo $view->LoadTemplate();
			exit();
		}   
	}  
	
	/**
	* Displays the login window
	* 
	* @param Array
	* @param PAView
	*/
	public function DisplayLogin(
		$request,
		$view)
	{ 
		$isLoggedIn = $this->loginController->getIsLoggedIn();
	}
	
	/**
	* Displays the protected page
	* 
	* @param Array
	* @param PAView
	*/
	public function DisplayPage(
		$request,
		$view)
	{ 
		$isLoggedIn = $this->loginController->getIsLoggedIn();
		
		// Does nothing for now.
	}
	
	
	/**
	* Gets the site url out of the session.
	* If not set tries to get out of the producer generated page that includes the module. 
	*/
	public function getSiteUrl()
	{		
		global $siteUrl;
		
		if ( isset( $_SESSION["siteUrl"] ) )
		{
			return $_SESSION["siteUrl"];
		}
		if ( isset( $siteUrl ))
		{
			$siteUrl = rtrim( $siteUrl, "/" );
			
			$_SESSION["siteUrl"] = $siteUrl;
			return $siteUrl;
		}
	}
		
	/**
	* Gets the current protected area name. 
	*/
	public function getArea()
	{
		global $areaName;
				
		if ( isset( $areaName ))
		{
			return $areaName;
		}
		if ( isset ( $this->request["areaName"] ))
		{
			return $this->request["areaName"];
		}
		else
		{
			return md5(  parse_url( $_SERVER["REQUEST_URI"], PHP_URL_PATH ));
		}
	}
	
	/**
	* Gets the current protected area title. 
	*/
	public function getAreaTitle()
	{
		global $areaTitle;
		
		if ( isset( $areaTitle ))
		{
			return $areaTitle;
		}
		if ( isset ( $this->request["areaTitle"] ))
		{
			return $this->request["areaTitle"];
		}
	}
	
	public function getAction()
	{
		if( isset( $this->action ))
		{
			return $this->action;
		}
		
		return null;
	}
}
?>