<?php

/**
 * Class DataLink
 *
 * Provides a data link to a file based entity storage
 * 
 * @author  Daniel Friedrich
 * @version 1.0 09.02.2011
 * @copyright (c)2011 zeta Software GmbH
 */
require_once('storage/StorageInfo.php');

class DataLink
{	
	private $dataSource;
	private $dataStorage;
	private $storageInfoPath;
	private $storageInfo;
	
	/**
	* Constructor
	*/
	public function DataLink($dataStorage, 
							 $dataSource)
	{
		$this->dataStorage = $dataStorage;
		$this->dataSource = $dataSource;
		$this->storageInfoPath = "$this->dataStorage/$this->dataSource/storage";
	}
	
	public function Connect()
	{
		if(!is_dir( $this->dataStorage ))
		{
			mkdir( $this->dataStorage );
		}
			
		if(!is_dir( "$this->dataStorage/$this->dataSource" ))
		{
			mkdir( "$this->dataStorage/$this->dataSource" );
		}	
		
		if(!is_dir( $this->getDataStoragePathAssets() ))
		{
			mkdir( $this->getDataStoragePathAssets() );
		}
		
		$this->loadStorageInformation();
	}
	
	public function getDataStoragePathAssets()
	{
		
		return "$this->dataStorage/$this->dataSource/assets/";
	}
	
	public function ReadObject( $id )
	{		
		if( is_numeric( $id ))
		{
			$row = array();
			$row["ID"] = $id;
			$files = scanDirEx( "$this->dataStorage/$this->dataSource", "$id.*.dat" );
			
			if( count ($files) > 0 )
			{
				foreach($files as $file)
				{
					$parts = explode(".", $file);				
	
					$posKey = count($parts)-2;
					$key = $parts[$posKey];
									
					$row[$key] = $this->readFile($id, $key);
				}	
					
				return $row;
			}
			return null;
		}
		return null;
	} 
	
	public function ReadAllObjects()
	{
		$objects = null;
		
		for ($i = 1; $i <= $this->storageInfo->getLastId(); $i++) 
		{
			$object = $this->ReadObject( $i );
			//print_r($object);
			
			if ( $object != null )
			{
				if( $objects == null )
				{
					$objects = array();	
				}
				
				$objects[] = $object;
			}
		}		
		
		return $objects;
	}
	
	public function StoreObject( $row )
	{
		$id = 0;
		
		foreach ($row as $key => $value)
		{	
			if ( $key == "ID" )
			{
				$id = $value;
				continue;
			}
			
			if ( $id == 0)
			{
				$id =  $this->storageInfo->IncreaseLastId();
			}
			
			$this->writeFile( $id, $key, stripslashes( $value ) );
		}
		
		$this->persistStorageInformation();
		
		return $id;
	}
	
	public function DeleteObject ( $id )
	{
		if( is_numeric( $id ) )
		{
			$files = scanDirEx( "$this->dataStorage/$this->dataSource", "$id.*.dat" );
			
			foreach($files as $file)
			{
				$this->deleteFile( $file );	
			}	
		}
		
		return true;
	}
	
	public function getStorageInfo()
	{
		 return $this->storageInfo;
	}
	
	private function readFile( $id, $key )
	{
		$path = "$this->dataStorage/$this->dataSource/$id.$key.dat";
		$content = file_get_contents( $path );
		
		return $content;
	}
	
	private function writeFile( $id, $key, $content)
	{
		$path = "$this->dataStorage/$this->dataSource/$id.$key.dat";

		file_put_contents($path, $content );
	}
	
	private function deleteFile( $fileName )
	{
		unlink("$this->dataStorage/$this->dataSource/$fileName");
	}
	
	private function loadStorageInformation()
	{	
		if( !file_exists($this->storageInfoPath) )
		{
			$this->storageInfo = new StorageInfo();	
		}
		else
		{
			$content = file_get_contents( $this->storageInfoPath );
			$this->storageInfo = unserialize( base64_decode( $content ));
		}
	}
	
	private function persistStorageInformation()
	{	
		file_put_contents(
			$this->storageInfoPath,
		 	base64_encode( serialize( $this->storageInfo )));
	}
}
?>