<?php
/**
 * Class Entry
 *
 * An guestbook entry object.
 * 
 * @author  Daniel Friedrich
 * @version 1.0 30.11.2011
 * @copyright (c)2011 zeta Software GmbH
 */

include_once 'Entity.php';

class Entry extends Entity
{
	private $name;
	private $email;
	private $homepage;
	private $text;
	private $ip;
	private $approved = false;
	private $orderPosition;
		
	/**
	* Constructor
	*/
	function Entry( $model ) 
	{	
		parent::Entity( $model );
	}
	
	public function Load( $row )
	{
		parent::Load( $row );
									  
		$this->name = $row['Name'];
		$this->email = $row['Email'];
		$this->homepage = $row['Homepage'];
		$this->ip = $row['IP'];
		$this->text = $row['Text'];
		$this->approved = $row['Approved'];
		$this->orderPosition = $row['OrderPosition'];
	}
	
	public function StoreRow( &$row )
	{
		parent::StoreRow( $row );
		
		$row['Name'] = $this->name;
		$row['Email'] = $this->email;
		$row['Homepage'] = $this->homepage;
		$row['IP'] = $this->ip;
		$row['Text'] = $this->text;
		$row['Approved'] = $this->approved;
		$row['OrderPosition'] = $this->orderPosition;
	}
	
	public function Store()
	{	
		$row = array();
				
		$this->StoreRow( $row );
			
		$id = $this->model->getDataLink()->StoreObject( $row );
		$this->id = $id;
		
		return $id;
	}
	
	public function Delete()
	{
		//echo "Deleting Item $this->id - $this->text";
		return $this->model->DeleteEntryById( $this->id );
	}
		
	static function cmp_Position($a, $b)
    {
        $al = strtolower( $a->getOrderPosition() );
        $bl = strtolower( $b->getOrderPosition() );
        if ( $al == $bl ) {
            return 0;
        }
        return ( $al > $bl ) ? +1 : -1;
    }
	
	public function getName() {
		return $this->name;
	}
	
	public function getEmail() {
		return $this->email;
	}
	
	public function getHomepage() {
		return $this->homepage;
	}

	public function getText() {
		return $this->text;
	}
	
	public function getIp() {
		return $this->ip;
	}
	
	public function getApproved() {
		return $this->approved;
	}
	
	public function getOrderPosition() {
		return $this->orderPosition;
	}
	
	public function setName($name) {
		$this->name = $name;
	}
	
	public function setEmail($email) {
		$this->email = $email;
	}
	
	
	public function setHomepage($homepage) {
		$this->homepage = $homepage;
	}
	
	public function setIp($ip) {
		$this->ip = $ip;
	}
	
	public function setApproved($approved) {
		$this->approved = $approved;
	}

	public function setText($text) {
		$this->text = $text;
	}
	
	public function setOrderPosition( $position ) {
		$this->orderPosition = $position;
	}
} 
?>