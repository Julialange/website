<?php

/**
 * Class StorageInfo
 *
 * Holds some information for file based entity storage
 * 
 * @author  Daniel Friedrich
 * @version 1.0 02.02.2011
 * @copyright (c)2011 zeta Software GmbH
 */

class StorageInfo  
{
	private $lastId;
	private $lastOrderPos = 1;
	
	public function getLastId()
	{
		return $this->lastId;
	}
	
	public function getLastOrderPosition()
	{
		return $this->lastOrderPos;
	}
	
	public function setLastOrderPosition( $pos )
	{
		$this->lastOrderPos = $pos;
	}
	
	public function IncreaseLastId()
	{
		if(empty( $this->lastId ))
		{
			$this->lastId = 1;
		}
		else
		{
			$this->lastId ++;
		}
		return $this->lastId;
	}
}
?>