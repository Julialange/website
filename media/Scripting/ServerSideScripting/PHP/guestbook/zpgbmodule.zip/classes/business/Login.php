<?php
/**
 * Class Login
 *
 * Manages login taks
 * 
 * @author  Daniel Friedrich
 * @version 1.5 04.04.2011
 * @copyright (c)2011 zeta Software GmbH
 */

Class Login
{   
	private $masterController = null;   
	
	/**  
	 * Contructor
	 *  
	 * @param Controller  
	 */  
	public function Login(
		$masterController)
	{   
		$this->masterController = $masterController;
	}

	/**
	* Checks if view / action requires login.
	* If yes, checks if user is logged in.
	* If not logged in stops execution.
	*/
	public function DoCheckProceedProcessing()
	{
		$proceed = true;
		
		switch( $this->masterController->getView() )
		{   
			case 'dataRequest':
				if( $this->getIsLoggedIn() || 
					$this->masterController->getAction() == "addNewEntry" )
				{
					$proceed = true;
				}
				break;
			case 'entries':
			case 'displayEntries':
			case 'editEntries':
				// No login required
				$proceed = true;	
				break;
				
			default:
				$proceed = false;
				break;		
		}
		
		// If valid for now check the views requirements.
		if ( $proceed )
		{
			if( $this->masterController->getAction() != null )
			{
				$proceed = false;
				
				switch ( $this->masterController->getAction() )
				{
					case 'storeEntry':
					case 'deleteEntry':
					case 'logout':
					case 'approveEntry':
					case 'moveUp':
					case 'moveDown':
					case 'dataRequest':
						if( $this->getIsLoggedIn() ||
							$this->masterController->IsApprovalKeyValid() )
						{
							$proceed = true;
						}
						break;	
						
					case 'addNewEntry':
					case 'login':
						// No login required
						$proceed = true;
						break;
					default:
						$proceed = false;
				}
			}
		}
		
		return $proceed;
	}
	
	public function getIsLoggedIn()
	{
		if ( isset( $_SESSION[$this->masterController->getDataDomain() . '_isLoggedIn'] ))
		{
			return true;
		}
		return false;
	}
	
	/**
	* Checks the login data of a user.
	*
	* @param Array Request
	* @param View
	*/
	public function LoginUser(
		$request,
		$view)
	{
		$pagePassword = $this->getAdminPagePassword();
		
		if($request["password"] == $pagePassword)
		{
			$_SESSION[$this->masterController->getDataDomain() . '_isLoggedIn'] = true;
			echo "ok"; 
		}
		else
		{
			echo "Das angegebene Kennwort ist nicht korrekt. Bitte versuchen Sie es erneut.";
		}
	}
	
	public function LogoutUser(
		$request,
		$view)
	{
		unset( $_SESSION[$this->masterController->getDataDomain() . '_isLoggedIn'] );
	}
	
	/**
	* Gets the set page password out of the session.
	* If not set tries to get out of the producer generated page that includes the cms. 
	*/
	public function getAdminPagePassword()
	{		
		if ( isset( $_SESSION[$this->masterController->getDataDomain() . "_pagePassword"] ) )
		{
			return $_SESSION[$this->masterController->getDataDomain() . "_pagePassword"];
		}
		if ( isset( $GLOBALS["adminPagePasswordGb"]) )
		{
			$_SESSION[$this->masterController->getDataDomain() . "_pagePassword"] = $GLOBALS["adminPagePasswordGb"];
			return $GLOBALS["adminPagePasswordGb"];
		}
	}
}
?>