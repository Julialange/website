<?php
class Configuration 
{
	public static $GB_VERSION = '1.01';
	public static $GB_DATE = '05.10.2010';
	public static $GB_DATASTORAGEDIR = 'GUESTBOOK_DATA';
	public static $GB_DATASTORAGEPATH_WEB = '/media/Scripting/ServerSideScripting/PHP/GUESTBOOK_DATA';
	public static $GB_MAXUPLOADSIZE = 5242880;
	public static $GB_MAXTEXTLENGTH = 1000;
	public static $GB_MAXTEXTLINES = 10;
	
	public static function getGuestboookDataStoragePath()
	{
		return dirname(realpath(__FILE__)) . "/../" . Configuration ::$GB_DATASTORAGEDIR;
	}
	
	public static function getGuestbookDataStoragePathWeb()
	{
		return Configuration::$GB_DATASTORAGEPATH_WEB;
	}
}
?>