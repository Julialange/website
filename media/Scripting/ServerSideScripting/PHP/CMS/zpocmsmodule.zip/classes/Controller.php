<?php
/**
 * Class Controller
 *
 * Controlles the inclusion of the Online-CMS frontend.
 */

require_once('business/Login.php');

class Controller
{   
	private $request = null;   
	private $action = null;   
	private $template = '';
	private $view = null;
	private $model = null;
	private $isAsyncCall = false;
	private $loginController = null;

	/**  
	 * Contructor
	 *  
	 * @param Array $request Array of $_GET & $_POST.  
	 */  
	public function Controller(
		$request)
	{   
		$this->request = $request;   
		$this->template = 'master';   
		$this->view = empty( $request['view'] ) ? 'displayPage' : $request['view'] ;
		
		if ( strcasecmp( $_SERVER["QUERY_STRING"], "edit" ) == 0)
		{
			$this->view = "editPage";
		}
		
		$this->action = empty( $request['action'] ) ? null : $request['action'];
		
		if (( !empty( $request['async'] ) &&
			 $request['async'] == "true" ) ||
			 $this->action == "dataRequest" ||
			 $this->action == "attachmentUpload" )
		{
			$this->isAsyncCall = true;
			$this->template = 'master2';
		}
		
		$this->loginController = new Login( $this );
		$this->model = new Model( $this->getDataDomain() );
		// Writes the page password and site URL to the session if not done already.
		$this->loginController->getPagePassword();
		$this->getSiteUrl();
	}   
	
	/**
	* Displays the content / Processes input
	* 
	* @return String Content. 
	*/
	public function Display()
	{   	
		$status = '';
		$action = $this->action;
		$view = new View();
		$view->SetTemplate( $this->template ); 
		$view->Assign('action', $action);
		$view->Assign('view', $this->view);
		$view->Assign('dataDomain', $this->getDataDomain());
		$view->Assign('isLoggedIn', $this->loginController->getIsLoggedIn() );
				
		$this->AssignConfigurationValues( $view );

		$this->loginController->DoCheckLoginRequired();
		
		if( isset( $action ))
		{
			switch ( $action )
			{
				case 'uploadImageAttachment':
					$this->view = "none";
					$this->ProcessImageUploadRequest($view);
					break;
					
				case 'uploadFileAttachment':
					$this->view = "none";
					$this->ProcessFileUploadRequest($view);
					break;
					
				case 'dataRequest':
					$this->view = "dataRequest";
					$this->ProcessDataRequest(
						$view);
					break;
					
				case 'storeArticle':
					if( isset( $this->request['articleId'] ) )
						{
							$this->StoreInput(
								$this->request,
								$view,
								$action);
						}
						else 
						{
							echo "No id given";	
						}
					exit();	
					break;
					
				case 'deleteArticle':
					$this->DeleteItem(
						$this->request,
						$view,
						$action);
					break;
					
				case 'login':
					$this->loginController->LoginUser( 
						$this->request,
						$view);
					exit();
					break;
					
				case 'logout':
					$this->loginController->LogoutUser( 
						$this->request,
						$view);
					break;
				case 'moveUp':
					$this->moveArticle(
						$this->request,
						$view,
						-1);
					break;
				case 'moveDown':
					$this->moveArticle(
						$this->request,
						$view,
						+1);
					break;
			}
		}
		
		switch( $this->view )
		{   				
			case 'articles':
				$this->DisplayArticles(
						$this->request, 
						$view);
				break;
				
			case 'editPage':
				$this->DisplayArticlesPage(
						$this->request,
						$view,
						true);
				break;
			
			case 'displayPage':
				$this->DisplayArticlesPage(
						$this->request,
						$view,
						false);
				break;
			
			default:
				break;			
		}
		
		return $view->LoadTemplate();   
	}  
	
	/**
	* Assigns the configuration to the given view
	* 
	* @param View
	*/
	public function AssignConfigurationValues(
		$view)
	{
		$configuration = array();
		
		$configuration['CMS_VERSION'] = Configuration::$CMS_VERSION;
		$configuration['CMS_DATE'] = Configuration::$CMS_DATE;
		$configuration['siteUrl'] = $this->getSiteUrl();
			
		$view->Assign( 'Configuration', $configuration );
	}
	
	/**
	* Processes an image data upload request. 
	* 
	* @param View
	*/
	public function ProcessImageUploadRequest( 
		$view )
	{
		$error = array();
		$data;
		
		$article = $this->tryLoadArticleFromRequest();
		
		if( $article != null && 
			array_key_exists("attachmentType", $this->request ) )
		{
			switch ( $this->request["attachmentType"])
			{
				case "image":
					
					$maxsize = Configuration::$CMS_MAXUPLOADSIZE;
					$type = $_FILES['imageFile1']['type'];
					$size = $_FILES['imageFile1']['size'];
					$name = $_FILES['imageFile1']['name'];
					$tmpname = $_FILES['imageFile1']['tmp_name'];
					
					if ( empty( $name ) )
					{
						$error[] = "Keine Datei ausgewählt.";
					}
					
					if ( $type != "image/gif" && 
						 $type != "image/jpeg" && 
						 $type != "image/pjpeg" && 
						 $type != "image/png") 
					{
						$error[] = "Es sind nur *.gif, *.jpeg, *.jpg, und *.png-Dateien zugelassen. Gegeben wurde '$type'.";
					}
 
					if ($size > $maxsize) 
					{
						$error[] = "Die Datei ist zu groß. Es sind maximal  ".($maxsize/1048576)." MB zugelassen.";
					}
					
					if ( empty( $error )) 
					{
						$filename = basename( $name );
					
						$asset = Asset::CreateImageAssetFromUploadedFile( $this->model, $_FILES["imageFile1"]);					
						if ( $asset != null ) 
						{
							$article->addAsset( $asset );
							$article->Store();
							
							$data  = "OK:::";
    						$data .= $this->getSiteUrl() . Configuration::getCmsDataStoragePathWeb() . "/" . $this->getDataDomain()  . "/assets/" . $asset->getFileName();

							// 2013-12-05, Uwe Keim: Wenn Bild groß genug ist, wird FancyBox verwendet, um zu zoomen.
							$largeFileName = $asset->getLargeFileName();
							if ( !isNullOrEmptyString($largeFileName) ) 
							{
								$data .= ":::";
								$data .= $this->getSiteUrl() . Configuration::getCmsDataStoragePathWeb() . "/" . $this->getDataDomain()  . "/assets/" . $largeFileName;
							}
						} 
						else 
						{
    						$data = "ERR:::Upload fehlgeschlagen.";
						} 
					}
					else 
					{
						$data = "ERR:::";
      					foreach ($error as $err) 
      					{
      						$data .= $err."<br>";
      					}
					}	
					break;
					
				default:
					$data = "Illegal function call.";
					break;
			}
		}
		else
		{
			$data = "Given article id does not exist.";
		}
		
		$view->Assign ( "content", $data );
	}

	/**
	* Processes a file data upload request. 
	* 
	* @param View
	*/
	public function ProcessFileUploadRequest( 
		$view )
	{
		$error = array();
		$data;
		
		$article = $this->tryLoadArticleFromRequest();
		
		if( $article != null && 
			array_key_exists("attachmentType", $this->request ) )
		{
			switch ( $this->request["attachmentType"])
			{
				case "file":
					
					$maxsize = Configuration::$CMS_MAXUPLOADSIZE;
					$type = $_FILES['fileFile1']['type'];
					$size = $_FILES['fileFile1']['size'];
					$name = $_FILES['fileFile1']['name'];
					$tmpname = $_FILES['fileFile1']['tmp_name'];
					
					if ( empty( $name ) )
					{
						$error[] = "Keine Datei ausgewählt.";
					}
					
					if ($size > $maxsize) 
					{
						$error[] = "Die Datei ist zu groß. Es sind maximal  ".($maxsize/1048576)." MB zugelassen.";
					}
					
					if ( empty( $error )) 
					{
						$filename = basename( $name );
					
						$asset = Asset::CreateFileAssetFromUploadedFile( $this->model, $_FILES["fileFile1"]);					
						if ( $asset != null ) 
						{
							$article->addAsset( $asset );
							$article->Store();
							
							$data  = "OK:::";
    						$data .= $this->getSiteUrl() . Configuration::getCmsDataStoragePathWeb() . "/" . $this->getDataDomain()  . "/assets/" . $asset->getFileName();
						} 
						else 
						{
    						$data = "ERR:::Upload fehlgeschlagen.";
						} 
					}
					else 
					{
						$data = "ERR:::";
      					foreach ($error as $err) 
      					{
      						$data .= $err."<br>";
      					}
					}	
					break;
					
				default:
					$data = "Illegal function call.";
					break;
			}
		}
		else
		{
			$data = "Given article id does not exist.";
		}
		
		$view->Assign ( "content", $data );
	}
	
	/**
	* Processes a data request. 
	* Sends only plain data, e.g. article heading or and text.
	*
	* @param View
	*/
	public function ProcessDataRequest(
		$view)
	{
		$article = null;
		$articleId = 0;
		$content = "";
		
		$article = $this->tryLoadArticleFromRequest();
		
		if( $article != null && 
			$article->getId() != 0)
		{
			$content = $article->getHeading() . ";;;" . $article->getText(); 
		}
		else 
		{
			$content = "Article with ID " . $articleId . " does not exist.";
		}
											   				
		$view->Assign( "content", $content );
	}
	
	/**
	* Displays the article page
	* 
	* @param Array
	* @param View
	* @param Bool Edit mode
	*/
	public function DisplayArticlesPage(
		$request,
		$view,
		$editMode)
	{ 
		$articles = $this->model->GetAllArticles();
		
		$isLoggedIn = $this->loginController->getIsLoggedIn();
		
		$viewArticlesTable = new View();
		$viewArticlesTable->SetTemplate('page_display');
		
		$this->AssignConfigurationValues( $viewArticlesTable );
		
		$viewArticlesTable->Assign('articles', $articles);
		$viewArticlesTable->Assign('isEditMode', $editMode);
		$viewArticlesTable->Assign('isLoggedIn', $isLoggedIn);
		$viewArticlesTable->Assign('dataDomain', $this->getDataDomain());
		$viewArticlesTable->Assign('view', $editMode == true && $isLoggedIn == true  ? "editPage" : $view->getTemplateName());
		   		
		$view->Assign('content', $viewArticlesTable->LoadTemplate());  									   
		$view->Assign('articles', $articles);
		$view->Assign('dataDomain', $this->getDataDomain());
	}
	
	/**
	* Displays the articles only
	* 
	* @param Array
	* @param View
	* @param Bool Edit mode
	*/
	public function DisplayArticles(
		$request,
		$view)
	{ 
		$articles = $this->model->GetAllArticles();
		
		$isLoggedIn = $this->loginController->getIsLoggedIn();
		
		$viewArticles = new View();
		$viewArticles->SetTemplate('articles');
				
		$viewArticles->Assign('articles', $articles);
		$viewArticles->Assign('isEditMode', $isLoggedIn);
		$viewArticles->Assign('isLoggedIn', $isLoggedIn);
		   		
		$view->Assign('content', $viewArticles->LoadTemplate());  									   
		$view->Assign('articles', $articles);
		$view->Assign('dataDomain', $this->getDataDomain());
	}
		
	/**
	* Stores the input from forms.
	*
	* @param Array
	* @param View
	*/
	public function StoreInput( 
		 $request,
		 $view,
		 $action)
	{
		$id = $this->doStoreArticle( $request, $view);
				
		if( $id != null &&
		   $id > 0 )
		{
			//$status_ = "Der Datensatz wurde erfolgreich gespeichert.";
			$status_ = "";
			echo $id;	
		}				
		else 
		{
			$status_ = "Fehler beim Speichern. Bitte versuchen Sie es erneut.";
		}
		
		$status  = $view->GetValue( 'statusMessage' );

		if ( !empty( $status ) )
		{
			$status .= '<br/>';
		}
		
		$status .= $status_;
		$view->Assign( "statusMessage", $status );
	}
	
	/**
	* For deleting items.
	*
	* @param Array
	* @param View
	* @param String
	*/
	public function DeleteItem( 
		 $request,
		 $view,
		 $action)
	{
		if( $action == "deleteArticle" )
		{
			$article = $this->tryLoadArticleFromRequest();
			if( $article != null )
			{
				$deleted = $article->Delete();
			}
		}
				
		if($deleted)
		{
			//$status = "Der Datensatz wurde gelöscht.";
			$status = ""; 	
		}				
		else 
		{
			$status = "Fehler beim Löschen des Datensatzes. Bitte versuchen Sie es erneut.";
		}
		
		$view->Assign( "statusMessage", $status );
	}
	
	/**
	* Gets the site url out of the session.
	* If not set tries to get out of the producer generated page that includes the cms. 
	*/
	public function getSiteUrl()
	{		
		global $siteUrl;
		
		if ( isset( $_SESSION["siteUrl"] ) )
		{
			return $_SESSION["siteUrl"];
		}
		if ( isset( $siteUrl ))
		{
			$siteUrl = rtrim( $siteUrl, "/" );
			
			$_SESSION["siteUrl"] = $siteUrl;
			return $siteUrl;
		}
	}
	
	/**
	* Gets the current data domain.
	* This is the directory within which the data for the current page is stored. 
	*/
	public function getDataDomain()
	{
		global $dataDomain;
		
		if ( isset( $dataDomain ))
		{
			return $dataDomain;
		}
		if ( isset ( $this->request["dataDomain"] ))
		{
			return $this->request["dataDomain"];
		}
	}
	
	public function getAction()
	{
		if( isset( $this->action ))
		{
			return $this->action;
		}
		
		return null;
	}
	
	public function getView()
	{
		if( isset( $this->view ))
		{
			return $this->view;
		}
		
		return null;
	}
	
	/**
	* Does the storing.
	*
	* @param Array Request
	* @param View
	*/
	private function doStoreArticle(
		$request,
		$view)
	{		
		if ( !isset($request['Text']) ||
			 empty($request['Text'] ))
		{
			echo "Bitte geben sie einen Text ein.";
			return false;	 	
		}
		
		$article = $this->tryLoadArticleFromRequest();
		
		if( $article == null )
		{	
			$article = new Article( $this->model );
		}
		
		if( array_key_exists("insertAtArticleId", $this->request ) && 
			$article->getId() == 0)
		{
			$this->model->EnsureArticleOrderPositionsSet();
			
			$insertAtArticleId = $this->request['insertAtArticleId'];
			
			if( is_numeric( $insertAtArticleId ) && 
				$insertAtArticleId != 0 )
			{				
				$articleBefore = $this->model->GetArticleById( $insertAtArticleId );
				
				$this->model->ShiftArticleOrderPositionsBy( 1, $articleBefore->getOrderPosition() + 1 );
				
				$article->setOrderPosition( $articleBefore->getOrderPosition() + 1 );
			}
			else
			{
				$article->setOrderPosition( $this->model->GetLastArticleOrderPosition() + 1 );
			}
		}
				
		$article->setHeading( $request['Heading'] );
		$article->setText( $request['Text'] );
		
		$article->DoCheckForUnusedAssetsAndRemove();
		
		return $article->Store();
	}
	
	private function moveArticle(
		$request,
		$view,
		$posChange)
	{
		$article = $this->tryLoadArticleFromRequest();
			
		if( $article != null )
		{
			$this->model->MoveArticle ( $article, $posChange );
		}		
	}
	
	private function tryLoadArticleFromRequest()
	{
		$articleId = 0;
		$article = null;
		
		if( array_key_exists("articleId", $this->request ) )
		{
			$articleId = $this->request['articleId'];
		}
		
		if( is_numeric( $articleId ) && 
			$articleId != 0 )
		{
			$article = $this->model->GetArticleById( $articleId );
		}
		
		return $article;
	}
}
?>