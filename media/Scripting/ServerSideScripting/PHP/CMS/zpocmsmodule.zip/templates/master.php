<?php
$isLoggedIn = $this->_['isLoggedIn'];
$view = $this->_['view'];
$dataDomain = $this->_['dataDomain'];
$inlineEditingIncludePath =  dirname( __FILE__ ) . "/../etc/_inline-editing/";
$inlineEditingIncludeUrl = $this->_['Configuration']['siteUrl'] . "/media/Scripting/ServerSideScripting/PHP/CMS/etc/_inline-editing/" ;

if ( $view == "editPage" || 
	 $isLoggedIn)
{
	include $inlineEditingIncludePath . "inline-editing.css";
?>
	<link type="text/css" href="<?php echo $this->_['Configuration']['siteUrl'] ?>/media/Scripting/ServerSideScripting/PHP/CMS/etc/jquery/theme/jquery-ui-1.8.11.custom.css" rel="Stylesheet" />	
	<script type="text/javascript" src="<?php echo $this->_['Configuration']['siteUrl'] ?>/media/Scripting/ServerSideScripting/PHP/CMS/etc/jquery/jquery-ui-1.8.11.custom.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->_['Configuration']['siteUrl'] ?>/media/Scripting/ServerSideScripting/PHP/CMS/etc/jquery/jquery.upload-1.0.2.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->_['Configuration']['siteUrl'] ?>/media/Scripting/ServerSideScripting/PHP/CMS/etc/tiny_mce/jquery.tinymce.js" ></script>	
	
	<script type="text/javascript">
		<?php include dirname( __FILE__ ) . "/../etc/zponlinecms.js" ?>
	</script>

	<script type="text/javascript">
	<!--
		$(function() {
		
			<?php 
			if ( !$isLoggedIn )
			{
			?>
			InitCms( "<?php echo( $dataDomain ); ?>", "<?php echo( session_id() ); ?>", true );
			<?php
			}
			else 
			{
			?>
			InitCms( "<?php echo( $dataDomain ); ?>", "<?php echo( session_id() ); ?>", false );
			<?php 
			} 
			?>
		});
	//-->
	</script>
	
	<style type="text/css" >
		input.text { margin-bottom:5px; padding: .4em; }
		fieldset { padding:0; border:0; margin-top:5px; }
		#validateTipsEdit { color: red;}
		.ui-dialog .ui-state-error { padding: .3em; }
		.ui-dialog-titlebar-close {  visibility: hidden;}
		.error { color: red; }
	</style>

	<div id="login-form" title="Anmelden" style="display:none;">
		<input type="password" name="password" placeholder="Kennwort" id="password" value="" class="text ui-widget-content ui-corner-all" style="width:225px; float: right" />
	</div>
	
	<div id="dialog-confirm-deletion" title="Artikel löschen" style="display:none;">
		<p>
			<span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 10px 0;"></span>
			<span id="dialog-confirm-deletion-text"></span>
		</p>
	</div>

	<div id="dialog-upload-image" title="Bild einfügen" style="display: none;">    
		<span id="dialog-upload-image-message" class="error" style="padding-top: 5px;"></span>
		<div id="dialog-upload-image-chooser" style="padding-top:5px;">
			<input id="imageFile1" type="file" name="imageFile1" accept="image/*" style="width:98%; display:block;"/>
		</div>
	</div>

	<div id="dialog-upload-file" title="Datei einfügen" style="display: none;">    
		<span id="dialog-upload-file-message" class="error" style="padding-top: 5px;"></span>
		<div id="dialog-upload-file-chooser" style="padding-top:5px;">
			<input id="fileFile1" type="file" name="fileFile1" style="width:98%; display:block;"/>
		</div>
	</div>

	<div id="dialog-edit-article" title="Artikel bearbeiten" style="display:none;">
		<p id="validateTipsEdit"></p>
		<fieldset>
			<input type="text" name="Heading" placeholder="Überschrift" id="zpocmsheading" class="text ui-widget-content ui-corner-all" style="width:99%; display:block; font-size: 1.1em" />
			<textarea name="Text" id="zpocmstext" class="text ui-widget-content ui-corner-all" style="width: 100%; height:410px; display:block;"></textarea>
		</fieldset>
	</div>
<?php 	
}
?>


<form name="masterForm" id="masterForm" action="?" method="post">
<input type="hidden" name="view"/>
<input type="hidden" name="action"/>

<script type="text/javascript"> 
<!--
var theForm = document.forms['masterForm'];
if (!theForm) {
    theForm = document.masterForm;
}
function __doPostBack(view, action) 
{
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) 
        {
    	theForm.view.value = view;
        theForm.action.value = action;
        theForm.submit();
    }
}
-->
</script>

<?php
	if(isset($this->_['statusMessage']) &&
	   !empty($this->_['statusMessage']))
	{
?>
		<div class="ui-state-error ui-corner-all" style="border:2px 2px 2px 2px;">
			<p><?php echo $this->_['statusMessage']; ?></p>
		</div>
<?php
	} 
?>

<?php
	if(isset($this->_['content']))
	{
		echo '<div id="cms_content">';
		echo $this->_['content'];
		echo '</div>';
	} 
?>
</form>