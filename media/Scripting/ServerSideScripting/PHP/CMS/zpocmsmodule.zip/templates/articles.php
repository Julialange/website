<?php
$articles = $this->_['articles'];
$isEditMode = $this->_['isEditMode'];
$isLoggedIn = $this->_['isLoggedIn'];

if($articles != null)
{
	foreach($articles as $currArticle) 
	{  
		if ( $isEditMode && $isLoggedIn)
		{
	?>
			<div class="inline-editing" onClick="javascript:void(0);" ondblclick="javascript:editArticle(<?php echo $currArticle->getId(); ?>,0);">
			<div class="inline-editing-menu-dummy"></div>	
			<div class="inline-editing-menu">
				<a class="inline-editing-edit" href="javascript:void(0);" onClick="javascript:editArticle(<?php echo $currArticle->getId(); ?>, 0); return false;" title="Bearbeiten">Bearbeiten</a>
				<a class="inline-editing-new" href="javascript:void(0);" onClick="javascript:editArticle(0, <?php echo $currArticle->getId(); ?>); return false;" title="Neuer Artikel einfügen">Neuer Artikel einfügen</a>
				<a class="inline-editing-delete" href="<?php echo 'javascript:deleteArticle(' . $currArticle->getId() . ',\'' . str_replace("'", "\\'", str_replace("\"", "&quot;", $currArticle->getHeading())) . '\')'; ?>" title="Löschen">Löschen</a>
				<a class="inline-editing-up-active" href="javascript:void(0);" onClick="javascript:updateArticlesAsync('<?php echo '?view=editPage&action=moveUp&articleId=' . $currArticle->getId(); ?>'); return false;" title="Nach oben verschieben">Nach oben verschieben</a>
				<a class="inline-editing-down-active"  href="javascript:void(0);" onClick="javascript:updateArticlesAsync('<?php echo '?view=editPage&action=moveDown&articleId=' . $currArticle->getId(); ?>'); return false;" title="Nach unten verschieben">Nach unten verschieben</a>
			</div> 
	<?php
		} 
	?>
		<div class="articlearea">
		<?php //echo $currArticle->getOrderPosition(); ?>
		<?php $heading = $currArticle->getHeading();   ?>
			<?php if ( !empty($heading) ) echo "<h2>" . $heading . "</h2>"; ?>
			<?php echo $currArticle->getText(); ?>
		</div>
	<?php
		if ( $isEditMode && $isLoggedIn)
		{ 	
	?>
			</div>
	<?php
		}
	} 
}
else 
{
	echo '<p>Für diese Seite wurde noch kein Inhalt erfasst.</p>';
}
?>